﻿
namespace COUG_CHAT_Hackathon_2021
{
    partial class profileWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxBorder = new System.Windows.Forms.PictureBox();
            this.myProfilePicture = new System.Windows.Forms.PictureBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.studentTypeLabel = new System.Windows.Forms.Label();
            this.hobbyLabel = new System.Windows.Forms.Label();
            this.majorLabel = new System.Windows.Forms.Label();
            this.nameEditButton = new System.Windows.Forms.Button();
            this.editGradButton = new System.Windows.Forms.Button();
            this.editHobbyButton = new System.Windows.Forms.Button();
            this.editMajorButton = new System.Windows.Forms.Button();
            this.discoverButton = new System.Windows.Forms.Button();
            this.signOutButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBorder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myProfilePicture)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxBorder
            // 
            this.pictureBoxBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pictureBoxBorder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBoxBorder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxBorder.Location = new System.Drawing.Point(41, 47);
            this.pictureBoxBorder.Name = "pictureBoxBorder";
            this.pictureBoxBorder.Size = new System.Drawing.Size(165, 161);
            this.pictureBoxBorder.TabIndex = 0;
            this.pictureBoxBorder.TabStop = false;
            // 
            // myProfilePicture
            // 
            this.myProfilePicture.Location = new System.Drawing.Point(49, 54);
            this.myProfilePicture.Name = "myProfilePicture";
            this.myProfilePicture.Size = new System.Drawing.Size(149, 146);
            this.myProfilePicture.TabIndex = 1;
            this.myProfilePicture.TabStop = false;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.ForeColor = System.Drawing.Color.White;
            this.nameLabel.Location = new System.Drawing.Point(485, 63);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(94, 20);
            this.nameLabel.TabIndex = 2;
            this.nameLabel.Text = "Adam Karaki";
            // 
            // studentTypeLabel
            // 
            this.studentTypeLabel.AutoSize = true;
            this.studentTypeLabel.ForeColor = System.Drawing.Color.White;
            this.studentTypeLabel.Location = new System.Drawing.Point(485, 106);
            this.studentTypeLabel.Name = "studentTypeLabel";
            this.studentTypeLabel.Size = new System.Drawing.Size(109, 20);
            this.studentTypeLabel.TabIndex = 3;
            this.studentTypeLabel.Text = "Undergraduate";
            // 
            // hobbyLabel
            // 
            this.hobbyLabel.AutoSize = true;
            this.hobbyLabel.ForeColor = System.Drawing.Color.White;
            this.hobbyLabel.Location = new System.Drawing.Point(485, 140);
            this.hobbyLabel.Name = "hobbyLabel";
            this.hobbyLabel.Size = new System.Drawing.Size(159, 60);
            this.hobbyLabel.TabIndex = 4;
            this.hobbyLabel.Text = "Hobbies: Video games\r\n                soccer\r\n                Twitch\r\n";
            // 
            // majorLabel
            // 
            this.majorLabel.AutoSize = true;
            this.majorLabel.ForeColor = System.Drawing.Color.White;
            this.majorLabel.Location = new System.Drawing.Point(485, 213);
            this.majorLabel.Name = "majorLabel";
            this.majorLabel.Size = new System.Drawing.Size(175, 20);
            this.majorLabel.TabIndex = 5;
            this.majorLabel.Text = "Major: Computer Science";
            // 
            // nameEditButton
            // 
            this.nameEditButton.Location = new System.Drawing.Point(455, 59);
            this.nameEditButton.Name = "nameEditButton";
            this.nameEditButton.Size = new System.Drawing.Size(24, 29);
            this.nameEditButton.TabIndex = 6;
            this.nameEditButton.Text = "~";
            this.nameEditButton.UseVisualStyleBackColor = true;
            this.nameEditButton.Click += new System.EventHandler(this.nameEditButton_Click);
            // 
            // editGradButton
            // 
            this.editGradButton.Location = new System.Drawing.Point(455, 97);
            this.editGradButton.Name = "editGradButton";
            this.editGradButton.Size = new System.Drawing.Size(24, 29);
            this.editGradButton.TabIndex = 7;
            this.editGradButton.Text = "~";
            this.editGradButton.UseVisualStyleBackColor = true;
            this.editGradButton.Click += new System.EventHandler(this.editGradButton_Click);
            // 
            // editHobbyButton
            // 
            this.editHobbyButton.Location = new System.Drawing.Point(455, 140);
            this.editHobbyButton.Name = "editHobbyButton";
            this.editHobbyButton.Size = new System.Drawing.Size(24, 29);
            this.editHobbyButton.TabIndex = 8;
            this.editHobbyButton.Text = "~";
            this.editHobbyButton.UseVisualStyleBackColor = true;
            this.editHobbyButton.Click += new System.EventHandler(this.editHobbyButton_Click);
            // 
            // editMajorButton
            // 
            this.editMajorButton.Location = new System.Drawing.Point(455, 209);
            this.editMajorButton.Name = "editMajorButton";
            this.editMajorButton.Size = new System.Drawing.Size(24, 29);
            this.editMajorButton.TabIndex = 9;
            this.editMajorButton.Text = "~";
            this.editMajorButton.UseVisualStyleBackColor = true;
            this.editMajorButton.Click += new System.EventHandler(this.editMajorButton_Click);
            // 
            // discoverButton
            // 
            this.discoverButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.discoverButton.ForeColor = System.Drawing.Color.White;
            this.discoverButton.Location = new System.Drawing.Point(41, 408);
            this.discoverButton.Name = "discoverButton";
            this.discoverButton.Size = new System.Drawing.Size(126, 57);
            this.discoverButton.TabIndex = 10;
            this.discoverButton.Text = "Discover People";
            this.discoverButton.UseVisualStyleBackColor = false;
            this.discoverButton.Click += new System.EventHandler(this.discoverButton_Click);
            // 
            // signOutButton
            // 
            this.signOutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.signOutButton.ForeColor = System.Drawing.Color.White;
            this.signOutButton.Location = new System.Drawing.Point(537, 408);
            this.signOutButton.Name = "signOutButton";
            this.signOutButton.Size = new System.Drawing.Size(123, 48);
            this.signOutButton.TabIndex = 11;
            this.signOutButton.Text = "Sign Out";
            this.signOutButton.UseVisualStyleBackColor = false;
            this.signOutButton.Click += new System.EventHandler(this.signOutButton_Click);
            // 
            // profileWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(706, 497);
            this.Controls.Add(this.signOutButton);
            this.Controls.Add(this.discoverButton);
            this.Controls.Add(this.editMajorButton);
            this.Controls.Add(this.editHobbyButton);
            this.Controls.Add(this.editGradButton);
            this.Controls.Add(this.nameEditButton);
            this.Controls.Add(this.majorLabel);
            this.Controls.Add(this.hobbyLabel);
            this.Controls.Add(this.studentTypeLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.myProfilePicture);
            this.Controls.Add(this.pictureBoxBorder);
            this.Name = "profileWindow";
            this.Text = "profileWindow";
            this.Load += new System.EventHandler(this.profileWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBorder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myProfilePicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxBorder;
        private System.Windows.Forms.PictureBox myProfilePicture;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label studentTypeLabel;
        private System.Windows.Forms.Label hobbyLabel;
        private System.Windows.Forms.Label majorLabel;
        private System.Windows.Forms.Button nameEditButton;
        private System.Windows.Forms.Button editGradButton;
        private System.Windows.Forms.Button editHobbyButton;
        private System.Windows.Forms.Button editMajorButton;
        private System.Windows.Forms.Button discoverButton;
        private System.Windows.Forms.Button signOutButton;
    }
}